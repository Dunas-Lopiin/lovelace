import { sortBirthday } from './aniversario.js';
import { sortRamal } from './ramais.js'