const express = require('express');
const app = express();
const port = 8080;
const url = "https://rickandmortyapi.com/api/character";
/* const fs = require('fs');
const bodyParser = require('body-parser'); */

app.use('/', express.static('src/home'));
app.use('/aboutme', express.static('src/aboutme'));
/* app.use(bodyParser.json()); */

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
