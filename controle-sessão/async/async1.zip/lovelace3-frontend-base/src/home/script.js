const url = "https://rickandmortyapi.com/api/character/";
const botao = document.getElementById("submit");
const nomes = [];

async function pesquisaId(ms){
  return new Promise((resolve, reject) => {
    let id = document.getElementById("number").value;
    try{
      fetch(url + id)
      .then(
        function(response) {
          if (response.status !== 200) {
            console.log('Temos problemas: Código  ' +
              response.status);
            return;
          }
          // Escreve a resposta em uma tabela
          setTimeout(resolve, ms);
          response.json().then(function(data) {
            console.log(data);
            nomes.push(data.name);
            console.log(nomes);
          });
        }
      )
    }
    catch(error) {
      console.log("o erro " + error + " ocorreu!");
      reject(console.log("um erro ocorreu"));
    }
  
    finally{
      console.log("pesquisa por id completa! Começando pesquisa por nome"); 
    }
  })
  
}

async function pesquisaNome(){
  await pesquisaId(2000);
  try{
    let personagem = nomes.length - 1;
    if(personagem < 0){
      personagem = 0;
    }
    console.log(personagem);
    fetch(url + "?name=" + nomes[personagem])
    .then(
      function(response) {
        if (response.status !== 200) {
          console.log('Temos problemas: Código  ' +
            response.status);
          return;
        }
        // Escreve a resposta em uma tabela
        
        response.json().then(function(data) {
          console.log(data);
        });
      }
    )
  }
  catch(error) {
    console.log("o erro " + error + " ocorreu!");
  }

  finally{
    console.log("pesquisa por nome concluida!");
  }
}

botao.addEventListener("click", pesquisaNome);